package com.example.servis3.dto;

public class MsgDto {

    private String to;

    private String title;

    private String body;

    public String getTo() {
        return to;
    }

    public String getTitle() {
        return title;
    }

    public String getBody() {
        return body;
    }
}
