package com.example.servis3.service;

import com.example.servis3.dto.MsgDto;

public interface MsgHandler {
    void doSomething(MsgDto msgDto);
}
