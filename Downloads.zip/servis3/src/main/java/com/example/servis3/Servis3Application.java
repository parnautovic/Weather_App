package com.example.servis3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servis3Application {

	public static void main(String[] args) {
		SpringApplication.run(Servis3Application.class, args);
	}

}
