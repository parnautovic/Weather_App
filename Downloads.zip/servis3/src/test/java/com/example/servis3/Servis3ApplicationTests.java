package com.example.servis3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servis3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
