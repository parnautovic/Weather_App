package com.example.servis1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servis1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
